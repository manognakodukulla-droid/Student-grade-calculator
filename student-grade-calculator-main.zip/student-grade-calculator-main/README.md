# student-grade-calculator
A student Grade calculator using html , css , javascript -- https://saisameerd.github.io/student-grade-calculator/


Extraordinarly styled web-app with javascirpt that calculates the total marks and give grades/result.
